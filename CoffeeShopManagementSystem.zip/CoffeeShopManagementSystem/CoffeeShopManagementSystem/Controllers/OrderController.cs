﻿using CoffeeShopManagementSystem.Models;
using Microsoft.AspNetCore.Mvc;

using System.Data;
using System.Data.SqlClient;
namespace CoffeeShopManagementSystem.Controllers
{
    public class OrderController : Controller
    {
        private IConfiguration configuration;

        public OrderController(IConfiguration _configuration)
        {
            configuration = _configuration;
        }

        //      public static  List<OrderModel> orders = new List<OrderModel>
        //{
        //    new OrderModel { OrderId = 1, OrderDate = DateTime.Now, CustomerName = "Alice", PaymentMode = "Credit Card", TotalAmount = 199.99m, ShippingAddress = "123 Main St", UserID = 101 },
        //    new OrderModel { OrderId = 2, OrderDate = DateTime.Now.AddDays(-1), CustomerName = "Bob", PaymentMode = "PayPal", TotalAmount = 299.99m, ShippingAddress = "124 Main St", UserID = 102 },
        //    new OrderModel { OrderId = 3, OrderDate = DateTime.Now.AddDays(-2), CustomerName = "Charlie", PaymentMode = "Cash", TotalAmount = 399.99m, ShippingAddress = "125 Main St", UserID = 103 },
        //    new OrderModel { OrderId = 4, OrderDate = DateTime.Now.AddDays(-3), CustomerName = "David", PaymentMode = null, TotalAmount = 499.99m, ShippingAddress = "126 Main St", UserID = 104 },
        //    new OrderModel { OrderId = 5, OrderDate = DateTime.Now.AddDays(-4), CustomerName = "Eva", PaymentMode = "Credit Card", TotalAmount = 599.99m, ShippingAddress = "127 Main St", UserID = 105 },
        //    new OrderModel { OrderId = 6, OrderDate = DateTime.Now.AddDays(-5), CustomerName = "Frank", PaymentMode = "Debit Card", TotalAmount = 699.99m, ShippingAddress = "128 Main St", UserID = 106 },
        //    new OrderModel { OrderId = 7, OrderDate = DateTime.Now.AddDays(-6), CustomerName = "Grace", PaymentMode = null, TotalAmount = 799.99m, ShippingAddress = "129 Main St", UserID = 107 },
        //    new OrderModel { OrderId = 8, OrderDate = DateTime.Now.AddDays(-7), CustomerName = "Hank", PaymentMode = "Credit Card", TotalAmount = 899.99m, ShippingAddress = "130 Main St", UserID = 108 },
        //    new OrderModel { OrderId = 9, OrderDate = DateTime.Now.AddDays(-8), CustomerName = "Ivy", PaymentMode = "PayPal", TotalAmount = 999.99m, ShippingAddress = "131 Main St", UserID = 109 },
        //    new OrderModel { OrderId = 10, OrderDate = DateTime.Now.AddDays(-9), CustomerName = "Jack", PaymentMode = "Cash", TotalAmount = 1099.99m, ShippingAddress = "132 Main St", UserID = 110 }
        //};

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult AddOrder()
        {
            ProductDropDown();
            return View();
        }

        public IActionResult OrderList()
        {
            string connectionString = this.configuration.GetConnectionString("ConnectionString");
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();
            SqlCommand command = connection.CreateCommand();
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = "[SP_Orders_SelectAll]";
            SqlDataReader reader = command.ExecuteReader();
            DataTable table = new DataTable();
            table.Load(reader);
            return View(table); return View();
        }


        public IActionResult DeleteOrder(int OrderID)
        {
            try
            {
                string connectionString = this.configuration.GetConnectionString("ConnectionString");
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();
                SqlCommand command = connection.CreateCommand();
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = "PR_Orders_DeleteByPK";
                command.Parameters.Add("@OrderID", SqlDbType.Int).Value = OrderID;
                command.ExecuteNonQuery();
                return RedirectToAction("OrderList");
            }
            catch (Exception e)
            {
                TempData["Error"] = e.Message;
                Console.WriteLine(e.ToString());
                return RedirectToAction("OrderList");
            }
        }

        public void ProductDropDown()
        {
            string connectionString = this.configuration.GetConnectionString("ConnectionString");
            SqlConnection connection1 = new SqlConnection(connectionString);
            connection1.Open();
            SqlCommand command1 = connection1.CreateCommand();
            command1.CommandType = CommandType.StoredProcedure;
            command1.CommandText = "SP_User_DropDown";
            SqlDataReader reader1 = command1.ExecuteReader();
            DataTable dataTable1 = new DataTable();
            dataTable1.Load(reader1);
            List<UserDropDownModel> userList = new List<UserDropDownModel>();
            foreach (DataRow data in dataTable1.Rows)
            {
                UserDropDownModel userDropDownModel = new UserDropDownModel();
                userDropDownModel.UserID = Convert.ToInt32(data["UserID"]);
                userDropDownModel.UserName = data["UserName"].ToString();
                userList.Add(userDropDownModel);
            }
            ViewBag.UserList = userList;
        }

        public IActionResult EditSave(int OrderID)
        {
            string connectionString = this.configuration.GetConnectionString("ConnectionString");
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();
            SqlCommand command = connection.CreateCommand();
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = "SP_Orders_SelectByPK";
            command.Parameters.AddWithValue("@OrderID", OrderID);
            SqlDataReader reader = command.ExecuteReader();
            DataTable table = new DataTable();
            table.Load(reader);
            OrderModel orderModel = new OrderModel();

            foreach (DataRow dataRow in table.Rows)
            {
                orderModel.OrderID = Convert.ToInt32(@dataRow["OrderID"]);
                orderModel.OrderDate = Convert.ToDateTime(@dataRow["OrderDate"]);
                orderModel.CustomerName = @dataRow["CustomerName"].ToString();
                orderModel.PaymentMode = @dataRow["PaymentMode"].ToString();
                orderModel.TotalAmount = Convert.ToDecimal(@dataRow["TotalAmount"]);
                orderModel.ShippingAddress = @dataRow["ShippingAddress"].ToString();
                orderModel.UserID = Convert.ToInt32(@dataRow["UserID"]);
            }


            ProductDropDown();
            return View("AddOrder", orderModel);
        }

        public IActionResult OrderSave(OrderModel orderModel)
        {
            try
            {
                if (orderModel.OrderID <= 0)
                {
                    ModelState.AddModelError("UserID", "A valid User is required.");
                }

                if (ModelState.IsValid)
                {
                    string connectionString = this.configuration.GetConnectionString("ConnectionString");
                    SqlConnection connection = new SqlConnection(connectionString);
                    connection.Open();
                    SqlCommand command = connection.CreateCommand();
                    command.CommandType = CommandType.StoredProcedure;
                    if (orderModel.OrderID == null)
                    {
                        command.CommandText = "SP_Orders_Insert";
                    }
                else
                {
                    command.CommandText = "PR_Orders_UpdateByPK";
                    command.Parameters.Add("@OrderID", SqlDbType.Int).Value = orderModel.OrderID;
                }
                    command.Parameters.Add("@OrderDate", SqlDbType.DateTime).Value = orderModel.OrderDate;
                    command.Parameters.Add("@CustomerName", SqlDbType.VarChar).Value = orderModel.CustomerName;
                    command.Parameters.Add("@PaymentMode", SqlDbType.VarChar).Value = orderModel.PaymentMode;
                    command.Parameters.Add("@TotalAmount", SqlDbType.Decimal).Value = orderModel.TotalAmount;
                    command.Parameters.Add("@ShippingAddress", SqlDbType.VarChar).Value = orderModel.ShippingAddress;
                    command.Parameters.Add("@UserID", SqlDbType.Int).Value = orderModel.UserID;
                    command.ExecuteNonQuery();
                    return RedirectToAction("OrderList");
                }
                ProductDropDown();
                return View("AddOrder", orderModel);
            }
            catch (Exception e)
            {
                TempData["Error"] = e.Message;
                Console.WriteLine(e.ToString());
                return RedirectToAction("OrderList");
            }
        }
    }
}
