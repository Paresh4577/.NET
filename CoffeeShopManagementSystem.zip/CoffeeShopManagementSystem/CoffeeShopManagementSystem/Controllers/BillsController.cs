﻿using CoffeeShopManagementSystem.Models;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using System.Data;

namespace CoffeeShopManagementSystem.Controllers
{
    public class BillsController : Controller
    {
        private IConfiguration configuration;

        public BillsController(IConfiguration _configuration)
        {
            configuration = _configuration;
        }

        //        List<BillsModel> bills = new List<BillsModel>
        //{
        //    new BillsModel { BillID = 1, BillNumber = "B1001", BillDate = DateTime.Now, OrderID = 1, TotalAmount = 399.98m, Discount = 20.00m, NetAmount = 379.98m, UserID = 101 },
        //    new BillsModel { BillID = 2, BillNumber = "B1002", BillDate = DateTime.Now.AddDays(-1), OrderID = 2, TotalAmount = 29.99m, Discount = 0, NetAmount = 29.99m, UserID = 102 },
        //    new BillsModel { BillID = 3, BillNumber = "B1003", BillDate = DateTime.Now.AddDays(-2), OrderID = 3, TotalAmount = 119.97m, Discount = 10.00m, NetAmount = 109.97m, UserID = 102 },
        //    new BillsModel { BillID = 4, BillNumber = "B1004", BillDate = DateTime.Now.AddDays(-3), OrderID = 4, TotalAmount = 199.96m, Discount = 15.00m, NetAmount = 184.96m, UserID = 103 },
        //    new BillsModel { BillID = 5, BillNumber = "B1005", BillDate = DateTime.Now.AddDays(-4), OrderID = 5, TotalAmount = 119.98m, Discount = 0, NetAmount = 119.98m, UserID = 104 },
        //    new BillsModel { BillID = 6, BillNumber = "B1006", BillDate = DateTime.Now.AddDays(-5), OrderID = 6, TotalAmount = 69.99m, Discount = 5.00m, NetAmount = 64.99m, UserID = 105 },
        //    new BillsModel { BillID = 7, BillNumber = "B1007", BillDate = DateTime.Now.AddDays(-6), OrderID = 7, TotalAmount = 239.97m, Discount = 30.00m, NetAmount = 209.97m, UserID = 106},
        //    new BillsModel { BillID = 8, BillNumber = "B1008", BillDate = DateTime.Now.AddDays(-7), OrderID = 8, TotalAmount = 179.98m, Discount = 0, NetAmount = 179.98m, UserID = 107 },
        //    new BillsModel { BillID = 9, BillNumber = "B1009", BillDate = DateTime.Now.AddDays(-8), OrderID = 9, TotalAmount = 99.99m, Discount = 8.00m, NetAmount = 91.99m, UserID = 108 },
        //    new BillsModel { BillID = 10, BillNumber = "B1010", BillDate = DateTime.Now.AddDays(-9), OrderID = 10, TotalAmount = 439.96m, Discount = 50.00m, NetAmount = 389.96m, UserID = 109 }
        //};

        public IActionResult Index()
        {
            return View();
        }
        public IActionResult BillList()
        {
            string connectionString = this.configuration.GetConnectionString("ConnectionString");
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();
            SqlCommand command = connection.CreateCommand();
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = "[SP_Bills_SelectAll]";
            SqlDataReader reader = command.ExecuteReader();
            DataTable table = new DataTable();
            table.Load(reader);
            return View(table); return View();
        }

        public IActionResult AddBill()
        {
            OrderDropDown();
            UserDropDown();
            return View();
        }

        public IActionResult DeleteBill(int BillID)
        {
            try
            {
                string connectionString = this.configuration.GetConnectionString("ConnectionString");
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();
                SqlCommand command = connection.CreateCommand();
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = "SP_Bills_DeleteByPK";
                command.Parameters.Add("@BillID", SqlDbType.Int).Value = BillID;
                command.ExecuteNonQuery();
                return RedirectToAction("BillList");
            }
            catch (Exception e)
            {
                TempData["Error"] = e.Message;
                Console.WriteLine(e.ToString());
                return RedirectToAction("BillList");
            }
        }

        public void OrderDropDown()
        {
            string connectionString = this.configuration.GetConnectionString("ConnectionString");
            SqlConnection connection1 = new SqlConnection(connectionString);
            connection1.Open();
            SqlCommand command1 = connection1.CreateCommand();
            command1.CommandType = CommandType.StoredProcedure;
            command1.CommandText = "SP_Order_DropDown";
            SqlDataReader reader1 = command1.ExecuteReader();
            DataTable dataTable1 = new DataTable();
            dataTable1.Load(reader1);
            List<OrderDropDownModel> orderList = new List<OrderDropDownModel>();
            foreach (DataRow data in dataTable1.Rows)
            {
                OrderDropDownModel orderDropDownModel = new OrderDropDownModel();
                orderDropDownModel.OrderID = Convert.ToInt32(data["OrderID"]);

                orderList.Add(orderDropDownModel);
            }
            ViewBag.OrderList = orderList;
        }

        public void UserDropDown()
        {
            string connectionString = this.configuration.GetConnectionString("ConnectionString");
            SqlConnection connection1 = new SqlConnection(connectionString);
            connection1.Open();
            SqlCommand command1 = connection1.CreateCommand();
            command1.CommandType = CommandType.StoredProcedure;
            command1.CommandText = "SP_User_DropDown";
            SqlDataReader reader1 = command1.ExecuteReader();
            DataTable dataTable1 = new DataTable();
            dataTable1.Load(reader1);
            List<UserDropDownModel> userList = new List<UserDropDownModel>();
            foreach (DataRow data in dataTable1.Rows)
            {
                UserDropDownModel userDropDownModel = new UserDropDownModel();
                userDropDownModel.UserID = Convert.ToInt32(data["UserID"]);
                userDropDownModel.UserName = data["UserName"].ToString();
                userList.Add(userDropDownModel);
            }
            ViewBag.UserList = userList;
        }

        public IActionResult EditSave(int BillID)
        {
            string connectionString = this.configuration.GetConnectionString("ConnectionString");
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();
            SqlCommand command = connection.CreateCommand();
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = "SP_Bills_SelectByPK";
            command.Parameters.AddWithValue("@BillID", BillID);
            SqlDataReader reader = command.ExecuteReader();
            DataTable table = new DataTable();
            table.Load(reader);
            BillsModel billsModel = new BillsModel();

            foreach (DataRow dataRow in table.Rows)
            {
                billsModel.BillID = Convert.ToInt32(@dataRow["BillID"]);
                billsModel.BillNumber = @dataRow["BillNumber"].ToString();
                billsModel.BillDate = Convert.ToDateTime(@dataRow["BillDate"]);
                billsModel.OrderID = Convert.ToInt32(@dataRow["OrderID"]);
                billsModel.TotalAmount = Convert.ToDecimal(@dataRow["TotalAmount"]);
                billsModel.Discount = Convert.ToDecimal(@dataRow["Discount"]);
                billsModel.NetAmount = Convert.ToDecimal(@dataRow["NetAmount"]);
                billsModel.UserID = Convert.ToInt32(@dataRow["UserID"]);
            }


            OrderDropDown();
            UserDropDown();
            return View("AddBill", billsModel);
        }
        public IActionResult BillSave(BillsModel billsModel)
        {
            //try
            //{
            //    if (orderModel.OrderID <= 0)
            //    {
            //        ModelState.AddModelError("UserID", "A valid User is required.");
            //    }

            if (ModelState.IsValid)
            {
                string connectionString = this.configuration.GetConnectionString("ConnectionString");
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();
                SqlCommand command = connection.CreateCommand();
                command.CommandType = CommandType.StoredProcedure;
                if (billsModel.BillID == null)
                {
                    command.CommandText = "SP_Bills_Insert";
                }
                else
                {
                    command.CommandText = "SP_Bills_UpdateByPK";
                    command.Parameters.Add("@BillID", SqlDbType.Int).Value = billsModel.BillID;
                }
                command.Parameters.Add("@BillNumber", SqlDbType.VarChar).Value = billsModel.BillNumber;
                command.Parameters.Add("@BillDate", SqlDbType.DateTime).Value = billsModel.BillDate;
                command.Parameters.Add("@OrderID", SqlDbType.Int).Value = billsModel.OrderID;
                command.Parameters.Add("@TotalAmount", SqlDbType.Decimal).Value = billsModel.TotalAmount;
                command.Parameters.Add("@Discount", SqlDbType.Decimal).Value = billsModel.Discount;
                command.Parameters.Add("@NetAmount", SqlDbType.Decimal).Value = billsModel.NetAmount;
                command.Parameters.Add("@UserID", SqlDbType.Int).Value = billsModel.UserID;
                command.ExecuteNonQuery();
                return RedirectToAction("BillList");
            }
            OrderDropDown();
            UserDropDown();
            return View("AddBill", billsModel);
            // }
            //catch (Exception e)
            //{
            //    TempData["Error"] = e.Message;
            //    Console.WriteLine(e.ToString());
            //    return RedirectToAction("OrderList");
            //}
        }
    }
}

