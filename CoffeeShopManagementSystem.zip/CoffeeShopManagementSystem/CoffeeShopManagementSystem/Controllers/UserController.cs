﻿using CoffeeShopManagementSystem.Models;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using System.Data;

namespace CoffeeShopManagementSystem.Controllers
{
    public class UserController : Controller
    {
        private IConfiguration configuration;

        public UserController(IConfiguration _configuration)
        {
            configuration = _configuration;
        }
        //      public static  List<UserModel> Users = new List<UserModel>
        //{
        //    new UserModel { UserID = 1, UserName = "Alice", Email = "alice@example.com", Password = "password1", MobileNo = "1234567890", Address = "123 Main St", IsActive = true },
        //    new UserModel { UserID = 2, UserName = "Bob", Email = "bob@example.com", Password = "password2", MobileNo = "1234567891", Address = "124 Main St", IsActive = true },
        //    new UserModel { UserID = 3, UserName = "Charlie", Email = "charlie@example.com", Password = "password3", MobileNo = "1234567892", Address = "125 Main St", IsActive = true },
        //    new UserModel { UserID = 4, UserName = "David", Email = "david@example.com", Password = "password4", MobileNo = "1234567893", Address = "126 Main St", IsActive = true },
        //    new UserModel { UserID = 5, UserName = "Eva", Email = "eva@example.com", Password = "password5", MobileNo = "1234567894", Address = "127 Main St", IsActive = true },
        //    new UserModel { UserID = 6, UserName = "Frank", Email = "frank@example.com", Password = "password6", MobileNo = "1234567895", Address = "128 Main St", IsActive = true },
        //    new UserModel { UserID = 7, UserName = "Grace", Email = "grace@example.com", Password = "password7", MobileNo = "1234567896", Address = "129 Main St", IsActive = true },
        //    new UserModel { UserID = 8, UserName = "Hank", Email = "hank@example.com", Password = "password8", MobileNo = "1234567897", Address = "130 Main St", IsActive = true },
        //    new UserModel { UserID = 9, UserName = "Ivy", Email = "ivy@example.com", Password = "password9", MobileNo = "1234567898", Address = "131 Main St", IsActive = true },
        //    new UserModel { UserID = 10, UserName = "Jack", Email = "jack@example.com", Password = "password10", MobileNo = "1234567899", Address = "132 Main St", IsActive = true }
        //};

        public IActionResult Index()
        {
            return View();
        }
        public IActionResult UserList()
        {
            string connectionString = this.configuration.GetConnectionString("ConnectionString");
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();
            SqlCommand command = connection.CreateCommand();
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = "SP_Users_SelectAll";
            SqlDataReader reader = command.ExecuteReader();
            DataTable table = new DataTable();
            table.Load(reader);
            return View(table);
        }
        public IActionResult EditSave(int UserID)
        {
            string connectionString = this.configuration.GetConnectionString("ConnectionString");
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();
            SqlCommand command = connection.CreateCommand();
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = "SP_Users_SelectById";
            command.Parameters.AddWithValue("@UserID", UserID);
            SqlDataReader reader = command.ExecuteReader();
            DataTable table = new DataTable();
            table.Load(reader);
            UserModel userModel = new UserModel();

            foreach (DataRow dataRow in table.Rows)
            {
                userModel.UserID = Convert.ToInt32(@dataRow["UserID"]);
                userModel.UserName = @dataRow["UserName"].ToString();
                userModel.Email = @dataRow["Email"].ToString();
                userModel.Password = @dataRow["Password"].ToString();
                userModel.MobileNo = @dataRow["MobileNo"].ToString();
                userModel.Address = @dataRow["Address"].ToString();
                userModel.IsActive = Convert.ToBoolean(@dataRow["IsActive"]);
            }



            return View("AddUser", userModel);
        }
        public IActionResult DeleteUser(int UserID)
        {
            try
            {
                string connectionString = this.configuration.GetConnectionString("ConnectionString");
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();
                SqlCommand command = connection.CreateCommand();
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = "SP_Users_DeleteByPK";
                command.Parameters.Add("@UserID", SqlDbType.Int).Value = UserID;
                command.ExecuteNonQuery();
                return RedirectToAction("UserList");
            }
            catch (Exception e)
            {
                TempData["Error"] = e.Message;
                Console.WriteLine(e.ToString());
                return RedirectToAction("UserList");
            }
        }
        public IActionResult AddUser()
        {
            return View();
        }

        public IActionResult UserSave(UserModel um)
        {
            if (ModelState.IsValid)
            {
                string connectionString = configuration.GetConnectionString("ConnectionString");

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand command = connection.CreateCommand())
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        if (um.UserID == null) // Insert new record
                        {
                            command.CommandText = "SP_Users_Insert";
                        }
                        else // Update existing record
                        {
                            command.CommandText = "SP_Users_UpdateByPK";
                            command.Parameters.Add("@UserID", SqlDbType.Int).Value = um.UserID;
                        }

                        command.Parameters.Add("@UserName", SqlDbType.VarChar).Value = um.UserName;
                        command.Parameters.Add("@Email", SqlDbType.VarChar).Value = um.Email;
                        command.Parameters.Add("@Password", SqlDbType.VarChar).Value = um.Password;
                        command.Parameters.Add("@MobileNo", SqlDbType.VarChar).Value = um.MobileNo;
                        command.Parameters.Add("@Address", SqlDbType.VarChar).Value = um.Address;
                        command.Parameters.Add("@IsActive", SqlDbType.Bit).Value = um.IsActive;

                        connection.Open();
                        command.ExecuteNonQuery();
                        return RedirectToAction("UserList");
                    }
                }
            }

            // If we reach here, something went wrong
            return View("AddUser", um);
        }

    }
}
