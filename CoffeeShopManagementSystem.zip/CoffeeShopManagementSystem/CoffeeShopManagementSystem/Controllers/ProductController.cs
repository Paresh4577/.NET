﻿using CoffeeShopManagementSystem.Models;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using System.Data;

namespace CoffeeShopManagementSystem.Controllers
{
    public class ProductController : Controller
    {
        private IConfiguration configuration;

        public ProductController(IConfiguration _configuration)
        {
            configuration = _configuration;
        }
        //        public static List<ProductModel> products = new List<ProductModel>
        //{
        //    new ProductModel { ProductID = 1, ProductName = "Product A", ProductPrice = 19.99m, ProductCode = "PA100", ProductDescription = "Description for Product A", UserID = 101 },
        //    new ProductModel { ProductID = 2, ProductName = "Product B", ProductPrice = 29.99m, ProductCode = "PB100", ProductDescription = "Description for Product B", UserID = 102 },
        //    new ProductModel { ProductID = 3, ProductName = "Product C", ProductPrice = 39.99m, ProductCode = "PC100", ProductDescription = "Description for Product C", UserID = 103 },
        //    new ProductModel { ProductID = 4, ProductName = "Product D", ProductPrice = 49.99m, ProductCode = "PD100", ProductDescription = "Description for Product D", UserID = 104 },
        //    new ProductModel { ProductID = 5, ProductName = "Product E", ProductPrice = 59.99m, ProductCode = "PE100", ProductDescription = "Description for Product E", UserID = 105 },
        //    new ProductModel { ProductID = 6, ProductName = "Product F", ProductPrice = 69.99m, ProductCode = "PF100", ProductDescription = "Description for Product F", UserID = 106 },
        //    new ProductModel { ProductID = 7, ProductName = "Product G", ProductPrice = 79.99m, ProductCode = "PG100", ProductDescription = "Description for Product G", UserID = 107 },
        //    new ProductModel { ProductID = 8, ProductName = "Product H", ProductPrice = 89.99m, ProductCode = "PH100", ProductDescription = "Description for Product H", UserID = 108 },
        //    new ProductModel { ProductID = 9, ProductName = "Product I", ProductPrice = 99.99m, ProductCode = "PI100", ProductDescription = "Description for Product I", UserID = 109 },
        //    new ProductModel { ProductID = 10, ProductName = "Product J", ProductPrice = 109.99m, ProductCode = "PJ100", ProductDescription = "Description for Product J", UserID = 110 }
        //};

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult ProductList()
        {
            string connectionString = this.configuration.GetConnectionString("ConnectionString");
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();
            SqlCommand command = connection.CreateCommand();
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = "SP_Product_SelectAll";
            SqlDataReader reader = command.ExecuteReader();
            DataTable table = new DataTable();
            table.Load(reader);
            return View(table);
        }
        public IActionResult DeleteProduct(int ProductID)
        {
            try
            {
                string connectionString = this.configuration.GetConnectionString("ConnectionString");
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();
                SqlCommand command = connection.CreateCommand();
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = "SP_Product_DeleteByPK";
                command.Parameters.Add("@ProductID", SqlDbType.Int).Value = ProductID;
                command.ExecuteNonQuery();
                return RedirectToAction("ProductList");
            }
            catch (Exception e)
            {
                TempData["Error"] = e.Message;
                Console.WriteLine(e.ToString());
                return RedirectToAction("ProductList");
            }
        }

        public IActionResult AddEditProduct()
        {
            ProductDropDown();
            return View();
        }

        public IActionResult EditSave(int ProductID)
        {
            string connectionString = this.configuration.GetConnectionString("ConnectionString");
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();
            SqlCommand command = connection.CreateCommand();
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = "SP_Products_SelectByPK";
            command.Parameters.AddWithValue("@ProductID", ProductID);
            SqlDataReader reader = command.ExecuteReader();
            DataTable table = new DataTable();
            table.Load(reader);
            ProductModel productModel = new ProductModel();

            foreach (DataRow dataRow in table.Rows)
            {
                productModel.ProductID = Convert.ToInt32(@dataRow["ProductID"]);
                productModel.ProductName = @dataRow["ProductName"].ToString();
                productModel.ProductCode = @dataRow["ProductCode"].ToString();
                productModel.ProductPrice = Convert.ToDecimal(@dataRow["ProductPrice"]);
                productModel.Description = @dataRow["Description"].ToString();
                productModel.UserID = Convert.ToInt32(@dataRow["UserID"]);
            }


            ProductDropDown();
            return View("AddEditProduct", productModel);
        }

        // Method to fetch the data in the drop-down list
        public void ProductDropDown()
        {
            string connectionString = this.configuration.GetConnectionString("ConnectionString");
            SqlConnection connection1 = new SqlConnection(connectionString);
            connection1.Open();
            SqlCommand command1 = connection1.CreateCommand();
            command1.CommandType = CommandType.StoredProcedure;
            command1.CommandText = "SP_User_DropDown";
            SqlDataReader reader1 = command1.ExecuteReader();
            DataTable dataTable1 = new DataTable();
            dataTable1.Load(reader1);
            List<UserDropDownModel> userList = new List<UserDropDownModel>();
            foreach (DataRow data in dataTable1.Rows)
            {
                UserDropDownModel userDropDownModel = new UserDropDownModel();
                userDropDownModel.UserID = Convert.ToInt32(data["UserID"]);
                userDropDownModel.UserName = data["UserName"].ToString();
                userList.Add(userDropDownModel);
            }
            ViewBag.UserList = userList;
        }

        public IActionResult ProductSave(ProductModel productModel)
        {
            try
            {
                if (productModel.UserID <= 0)
                {
                    ModelState.AddModelError("UserID", "A valid User is required.");
                }

                if (ModelState.IsValid)
                {
                    string connectionString = this.configuration.GetConnectionString("ConnectionString");
                    SqlConnection connection = new SqlConnection(connectionString);
                    connection.Open();
                    SqlCommand command = connection.CreateCommand();
                    command.CommandType = CommandType.StoredProcedure;
                    if (productModel.ProductID == null)
                    {
                        command.CommandText = "SP_Products_Insert";
                    }
                    else
                    {
                        command.CommandText = "SP_Product_UpdateByPK";
                        command.Parameters.Add("@ProductID", SqlDbType.Int).Value = productModel.ProductID;
                    }
                    command.Parameters.Add("@ProductName", SqlDbType.VarChar).Value = productModel.ProductName;
                    command.Parameters.Add("@ProductCode", SqlDbType.VarChar).Value = productModel.ProductCode;
                    command.Parameters.Add("@ProductPrice", SqlDbType.Decimal).Value = productModel.ProductPrice;
                    command.Parameters.Add("@Description", SqlDbType.VarChar).Value = productModel.Description;
                    command.Parameters.Add("@UserID", SqlDbType.Int).Value = productModel.UserID;
                    command.ExecuteNonQuery();
                    return RedirectToAction("ProductList");
                }
                ProductDropDown();
                return View("AddEditProduct", productModel);
            }
            catch (Exception e)
            {
                TempData["Error"] = e.Message;
                Console.WriteLine(e.ToString());
                return RedirectToAction("ProductList");
            }





        }
    }
}

