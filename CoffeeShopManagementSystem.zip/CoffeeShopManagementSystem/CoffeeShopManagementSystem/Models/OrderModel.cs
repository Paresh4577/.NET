﻿using System.ComponentModel.DataAnnotations;
namespace CoffeeShopManagementSystem.Models
{
    public class OrderModel
    {
        public int? OrderID { get; set; }

        [Required(ErrorMessage = "Order Date Required")]
        public DateTime OrderDate {  get; set; }

        [Required(ErrorMessage = "Customer Name is Required")]
        public string CustomerName { get; set; }

        public string PaymentMode { get; set; }

        public decimal TotalAmount { get; set; }

        public string ShippingAddress {  get; set; }

        public int UserID { get; set; } 

    }

    public class OrderDropDownModel
    {
        public int OrderID { get; set; }
        
    }
}
