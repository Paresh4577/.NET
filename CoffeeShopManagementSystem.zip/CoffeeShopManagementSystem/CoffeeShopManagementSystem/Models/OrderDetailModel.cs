﻿using System.ComponentModel.DataAnnotations;
namespace CoffeeShopManagementSystem.Models
{
    public class OrderDetailModel
    {

        public int? OrderDetailID{ get; set; }

        [Required(ErrorMessage = "Order Id is Required")]
        public int OrderID { get; set; } 
        [Required(ErrorMessage = "Product Id is Required")]
        public int ProductID { get; set; } 
        [Required(ErrorMessage = "Quantity Field is Required")]
        public int Quantity { get; set; }
        [Required(ErrorMessage = "Amount is Required")]
        public decimal Amount {  get; set; }
        [Required(ErrorMessage = "Total Amount is Required")]
        public decimal TotalAmount { get; set; }
        [Required(ErrorMessage = "User Id is Required")]
        public int UserID { get; set; } 

    }
}
