﻿using System.ComponentModel.DataAnnotations;

namespace CoffeeShopManagementSystem.Models
{
    public class UserModel
    {
        public int? UserID { get; set; }

        [Required(ErrorMessage = "UserName can't be empty")]
        [RegularExpression(@"^[a-zA-Z\s]+$", ErrorMessage = "UserName can only contain letters and spaces")]
        [StringLength(30, ErrorMessage = "UserName maximum 30 characters")]
        public string UserName { get; set; }

        [Required(ErrorMessage = "Email can't be empty")]
        [RegularExpression(@"^[^@\s]+@[^@\s]+\.[^@\s]+$", ErrorMessage = "Invalid Email Address")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Password can't be empty")]
        [StringLength(11, MinimumLength = 6, ErrorMessage = "Password must be between 6 and 100 characters")]
        public string Password { get; set; }

        [Required(ErrorMessage = "Phone Number can't be empty")]
       
        public string MobileNo {  get; set; }

        [Required(ErrorMessage = "Address can't be empty")]
        [StringLength(500, ErrorMessage = "Address maximum 500 characters")]
        public string Address {  get; set; }

        [Required(ErrorMessage = "Active can't be empty")]
        public bool IsActive {  get; set; }
    }


    public class UserDropDownModel
    {
        public int UserID { get; set; }
        public string UserName { get; set; }
    }
}
