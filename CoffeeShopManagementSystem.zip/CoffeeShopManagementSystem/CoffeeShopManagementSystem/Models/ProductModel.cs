﻿using System.ComponentModel.DataAnnotations;

namespace CoffeeShopManagementSystem.Models
{
    public class ProductModel
    {
        public int? ProductID { get; set; }

        [Required(ErrorMessage = "The Product Name field is required.")]
        public string ProductName { get; set; }

        [Required(ErrorMessage = "The Product Price field is required.")]
        public decimal ProductPrice { get; set; }

        [Required(ErrorMessage = "The Product Code field is required.")]
        public string ProductCode { get; set; }

        [Required(ErrorMessage = "The Product Description field is required.")]
        public string Description { get; set; }

        [Required(ErrorMessage = "The UserID is required.")]
        public int UserID { get; set; }

    }

    public class ProductDropDownModel
    {
        public int ProductID { get; set; }

        public string ProductName { get; set; }

    }
}
