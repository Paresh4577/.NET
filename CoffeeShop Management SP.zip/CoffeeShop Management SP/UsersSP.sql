/*Stord PROCEDURE  for Users Table*/

/*Select All Users*/
CREATE PROCEDURE SP_Users_SelectAll
AS
BEGIN
    SELECT UserID, UserName, Email, Password, MobileNo, Address, IsActive
    FROM Users
    ORDER BY UserName;
END;

/*Select User by UserId*/
CREATE PROCEDURE SP_Users_SelectById
    @UserID INT
AS
BEGIN
    SELECT UserID, UserName, Email, Password, MobileNo, Address, IsActive
    FROM Users
    WHERE UserID = @UserID;
END;

/*Insert User*/
CREATE PROCEDURE SP_Users_Insert
    @UserName VARCHAR(100),
    @Email VARCHAR(100),
    @Password VARCHAR(100),
    @MobileNo VARCHAR(15),
    @Address VARCHAR(100),
    @IsActive BIT
AS
BEGIN
    INSERT INTO Users (UserName, Email, Password, MobileNo, Address, IsActive)
    VALUES (@UserName, @Email, @Password, @MobileNo, @Address, @IsActive);
END;

/*Update User by Primary Key*/
CREATE PROCEDURE SP_Users_UpdateByPK
    @UserID INT,
    @UserName VARCHAR(100),
    @Email VARCHAR(100),
    @Password VARCHAR(100),
    @MobileNo VARCHAR(15),
    @Address VARCHAR(100),
    @IsActive BIT
AS
BEGIN
    UPDATE Users
    SET UserName = @UserName, Email = @Email, Password = @Password, MobileNo = @MobileNo, Address = @Address, IsActive = @IsActive
    WHERE UserID = @UserID;
END;

/*Delete User by Primary Key*/
CREATE PROCEDURE SP_Users_DeleteByPK
    @UserID INT
AS
BEGIN
    DELETE FROM Users
    WHERE UserID = @UserID;
END;


