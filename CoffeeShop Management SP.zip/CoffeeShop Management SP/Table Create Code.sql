CREATE DATABASE CoffeeShopManagement;
USE CoffeeShopManagement;

-- User Table
CREATE TABLE Users (
    UserID INT NOT NULL IDENTITY(1, 1),
    PRIMARY KEY (UserID),
    UserName VARCHAR(100) NOT NULL,
    Email VARCHAR(100) NOT NULL,
    Password VARCHAR(100) NOT NULL,
    MobileNo VARCHAR(15) NOT NULL,
    Address VARCHAR(100) NOT NULL,
    IsActive BIT NOT NULL,
);

-- Product Table
CREATE TABLE Product (
    ProductID INT NOT NULL IDENTITY(1, 1),
    ProductName VARCHAR(100) NOT NULL,
    ProductPrice DECIMAL(10,2) NOT NULL,
    ProductCode VARCHAR(100) NOT NULL,
    Description VARCHAR(100) NOT NULL,
    UserID INT NOT NULL,
    PRIMARY KEY (ProductID),
    FOREIGN KEY (UserID) REFERENCES Users(UserID)
);

-- Order Table
CREATE TABLE Orders (
    OrderID INT NOT NULL IDENTITY(1, 1),
    OrderDate DATETIME NOT NULL,
    CustomerName VARCHAR(100) NOT NULL,
    PaymentMode VARCHAR(100),
    TotalAmount DECIMAL(10,2) NOT NULL,
    ShippingAddress VARCHAR(100) NOT NULL,
    UserID INT NOT NULL,
    PRIMARY KEY (OrderID),
    FOREIGN KEY (UserID) REFERENCES Users(UserID)
);

-- OrderDetail Table
CREATE TABLE OrderDetail (
    OrderDetailID INT NOT NULL IDENTITY(1, 1),
    OrderID INT NOT NULL,
    ProductID INT NOT NULL,
    Quantity INT NOT NULL,
    Amount DECIMAL(10,2) NOT NULL,
    TotalAmount DECIMAL(10,2) NOT NULL,
    UserID INT NOT NULL,
    PRIMARY KEY (OrderDetailID),
    FOREIGN KEY (OrderID) REFERENCES Orders (OrderID),
    FOREIGN KEY (ProductID) REFERENCES Product(ProductID),
    FOREIGN KEY (UserID) REFERENCES Users(UserID)
);

-- Bills Table
CREATE TABLE Bills (
    BillID INT NOT NULL IDENTITY(1, 1),
    BillNumber VARCHAR(100) NOT NULL,
    BillDate DATETIME NOT NULL,
    OrderID INT NOT NULL,
    TotalAmount DECIMAL(10,2) NOT NULL,
    Discount DECIMAL(10,2),
    NetAmount DECIMAL(10,2) NOT NULL,
    UserID INT NOT NULL,
    PRIMARY KEY (BillID),
    FOREIGN KEY (OrderID) REFERENCES Orders (OrderID),
    FOREIGN KEY (UserID) REFERENCES Users (UserID)
);
