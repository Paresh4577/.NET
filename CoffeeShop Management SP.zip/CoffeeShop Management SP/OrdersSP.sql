--Orders Table Stored Procedures

--Select All Orders

CREATE PROCEDURE [dbo].[SP_Orders_SelectAll]
AS
BEGIN
    SELECT OrderID, OrderDate, CustomerName, PaymentMode, TotalAmount, ShippingAddress, UserID
    FROM Orders
    ORDER BY OrderDate;
END;

--Select Order by Primary Key
CREATE PROCEDURE [dbo].[SP_Orders_SelectByPK]
    @OrderID INT
AS
BEGIN
    SELECT OrderID, OrderDate, CustomerName, PaymentMode, TotalAmount, ShippingAddress, UserID
    FROM Orders
    WHERE OrderID = @OrderID;
END;

--Insert Order
CREATE PROCEDURE [dbo].[SP_Orders_Insert]
    @OrderDate DATETIME,
    @CustomerName VARCHAR(100),
    @PaymentMode VARCHAR(100),
    @TotalAmount DECIMAL(10,2),
    @ShippingAddress VARCHAR(100),
    @UserID INT
AS
BEGIN
    INSERT INTO Orders (OrderDate, CustomerName, PaymentMode, TotalAmount, ShippingAddress, UserID)
    VALUES (@OrderDate, @CustomerName, @PaymentMode, @TotalAmount, @ShippingAddress, @UserID);
END;


--Update Order by Primary Key
CREATE PROCEDURE [dbo].[PR_Orders_UpdateByPK]
    @OrderID INT,
    @OrderDate DATETIME,
    @CustomerName VARCHAR(100),
    @PaymentMode VARCHAR(100),
    @TotalAmount DECIMAL(10,2),
    @ShippingAddress VARCHAR(100),
    @UserID INT
AS
BEGIN
    UPDATE Orders
    SET 
	OrderDate		= @OrderDate, 
	CustomerName	= @CustomerName, 
	PaymentMode		= @PaymentMode, 
	TotalAmount		= @TotalAmount, 
	ShippingAddress = @ShippingAddress, 
	UserID			= @UserID
    WHERE OrderID = @OrderID;
END;

--Delete Order by Primary Key
CREATE PROCEDURE [dbo].[PR_Orders_DeleteByPK]
    @OrderID INT
AS
BEGIN
    DELETE FROM Orders
    WHERE OrderID = @OrderID;
END;