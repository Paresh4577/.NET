/*Products Table Stored Procedures */

/*Select All Products*/
CREATE PROCEDURE SP_Products_SelectAll
AS
BEGIN
    SELECT ProductID, ProductName, ProductPrice, ProductCode, Description, UserID
    FROM Products
    ORDER BY ProductName;
END;

--Select Product by Primary Key
CREATE PROCEDURE SP_Products_SelectByPK
    @ProductID INT
AS
BEGIN
    SELECT ProductID, ProductName, ProductPrice, ProductCode, Description, UserID
    FROM Products
    WHERE ProductID = @ProductID;
END;

--Insert Product
CREATE PROCEDURE SP_Products_Insert
    @ProductName VARCHAR(100),
    @ProductPrice DECIMAL(10,2),
    @ProductCode VARCHAR(100),
    @Description VARCHAR(100),
    @UserID INT
AS
BEGIN
    INSERT INTO Products (ProductName, ProductPrice, ProductCode, Description, UserID)
    VALUES (@ProductName, @ProductPrice, @ProductCode, @Description, @UserID);
END;

--Update Product by Primary Key
CREATE PROCEDURE SP_Products_UpdateByPK
    @ProductID INT,
    @ProductName VARCHAR(100),
    @ProductPrice DECIMAL(10,2),
    @ProductCode VARCHAR(100),
    @Description VARCHAR(100),
    @UserID INT
AS
BEGIN
    UPDATE Products
    SET ProductName = @ProductName, ProductPrice = @ProductPrice, ProductCode = @ProductCode, Description = @Description, UserID = @UserID
    WHERE ProductID = @ProductID;
END;

--Delete Product by Primary Key
CREATE PROCEDURE SP_Products_DeleteByPK
    @ProductID INT
AS
BEGIN
    DELETE FROM Products
    WHERE ProductID = @ProductID;
END;
