--OrderDetails Table Stored Procedures

--Select All OrderDetails
CREATE PROCEDURE [dbo].[SP_OrderDetails_SelectAll]
AS
BEGIN
    SELECT OrderDetailID, OrderID, ProductID, Quantity, Amount, TotalAmount, UserID
    FROM OrderDetails
    ORDER BY OrderID;
END;

--Select OrderDetail by Primary Key
CREATE PROCEDURE [dbo].[SP_OrderDetails_SelectByPK]
    @OrderDetailID INT
AS
BEGIN
    SELECT OrderDetailID, OrderID, ProductID, Quantity, Amount, TotalAmount, UserID
    FROM OrderDetails
    WHERE OrderDetailID = @OrderDetailID;
END;

--Insert OrderDetail
CREATE PROCEDURE [dbo].[SP_OrderDetails_Insert]
    @OrderID INT,
    @ProductID INT,
    @Quantity INT,
    @Amount DECIMAL(10,2),
    @TotalAmount DECIMAL(10,2),
    @UserID INT
AS
BEGIN
    INSERT INTO OrderDetails (OrderID, ProductID, Quantity, Amount, TotalAmount, UserID)
    VALUES (@OrderID, @ProductID, @Quantity, @Amount, @TotalAmount, @UserID);
END;

--Update OrderDetail by Primary Key
CREATE PROCEDURE [dbo].[SP_OrderDetails_UpdateByPK]
    @OrderDetailID INT,
    @OrderID INT,
    @ProductID INT,
    @Quantity INT,
    @Amount DECIMAL(10,2),
    @TotalAmount DECIMAL(10,2),
    @UserID INT
AS
BEGIN
    UPDATE OrderDetails
    SET 

	OrderID		= @OrderID, 
	ProductID	= @ProductID, 
	Quantity	= @Quantity, 
	Amount		= @Amount, 
	TotalAmount = @TotalAmount, 
	UserID		= @UserID
    
	WHERE OrderDetailID = @OrderDetailID;
END;

--Delete OrderDetail by Primary Key
CREATE PROCEDURE [dbo].[PR_OrderDetails_DeleteByPK]
    @OrderDetailID INT
AS
BEGIN
    DELETE FROM OrderDetails
    WHERE OrderDetailID = @OrderDetailID;
END;