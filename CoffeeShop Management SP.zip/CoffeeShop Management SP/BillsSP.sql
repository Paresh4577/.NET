--Bills Table Stored Procedures
--Select All Bills
CREATE PROCEDURE [dbo].[SP_Bills_SelectAll]
AS
BEGIN
    SELECT BillID, BillNumber, BillDate, OrderID, TotalAmount, Discount, NetAmount, UserID
    FROM Bills
    ORDER BY BillDate;
END;

--Select Bill by Primary Key
CREATE PROCEDURE [dbo].[SP_Bills_SelectByPK]
    @BillID INT
AS
BEGIN
    SELECT BillID, BillNumber, BillDate, OrderID, TotalAmount, Discount, NetAmount, UserID
    FROM Bills
    WHERE BillID = @BillID;
END;
--Insert Bill
CREATE PROCEDURE [dbo].[SP_Bills_Insert]
    @BillNumber VARCHAR(100),
    @BillDate DATETIME,
    @OrderID INT,
    @TotalAmount DECIMAL(10,2),
    @Discount DECIMAL(10,2),
    @NetAmount DECIMAL(10,2),
    @UserID INT
AS
BEGIN
    INSERT INTO Bills (BillNumber, BillDate, OrderID, TotalAmount, Discount, NetAmount, UserID)
    VALUES (@BillNumber, @BillDate, @OrderID, @TotalAmount, @Discount, @NetAmount, @UserID);
END;

--Update Bill by Primary Key
CREATE PROCEDURE [dbo].[SP_Bills_UpdateByPK]
    @BillID INT,
    @BillNumber VARCHAR(100),
    @BillDate DATETIME,
    @OrderID INT,
    @TotalAmount DECIMAL(10,2),
    @Discount DECIMAL(10,2),
    @NetAmount DECIMAL(10,2),
    @UserID INT
AS
BEGIN
    UPDATE Bills
    SET 
	BillNumber	= @BillNumber, 
	BillDate	= @BillDate, 
	OrderID		= @OrderID, 
	TotalAmount = @TotalAmount, 
	Discount	= @Discount, 
	NetAmount	= @NetAmount, 
	UserID		= @UserID
    WHERE BillID = @BillID;
END;

--Delete Bill by Primary Key
CREATE PROCEDURE [dbo].[SP_Bills_DeleteByPK]
    @BillID INT
AS
BEGIN
    DELETE FROM Bills
    WHERE BillID = @BillID;
END;