﻿using System;


namespace Pro_3
{
    abstract class Sum
    {
        // First abstract method
        public abstract int SumOfTwo(int a, int b);

        // Second abstract method
        public abstract int SumOfThree(int a, int b, int c);
    }
}
